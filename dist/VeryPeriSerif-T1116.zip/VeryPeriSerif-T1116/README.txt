Very Peri Serif T1116

Renamed installation copy of Very Peri Serif 1.116.
Переименованная копия Very Peri Serif 1.116 для отдельной установки.

Cyrillic author / Автор кириллицы: Yerbolat Rakhatuly (DEW).

Install both TTFs. Font-menu family / Имя в списке шрифтов: Very Peri Serif T1116.
Regular and Italic. Outlines, kerning, ligatures and mark anchors match the release.
Контуры, кернинг, лигатуры и ударения совпадают с основным выпуском.
Only naming metadata differs / Изменены внутренние названия и идентификаторы.

Licence / Лицензия: SIL Open Font License 1.1, OFL.txt.
Source / Исходники: https://github.com/rahatulyerbolat05-dotcom/Very-Peri-serif
