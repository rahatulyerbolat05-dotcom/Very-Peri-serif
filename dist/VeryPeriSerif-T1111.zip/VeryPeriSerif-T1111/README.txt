Very Peri Serif T1111

Renamed installation copy of Very Peri Serif 1.111.
Переименованная копия Very Peri Serif 1.111 для отдельной установки.

Install both TTF files. In the font menu choose: Very Peri Serif T1111.
Установите оба файла TTF. В списке шрифтов выберите: Very Peri Serif T1111.

Regular and Italic. Outlines, spacing, kerning, ligatures and mark anchors
are identical to release 1.111; only naming/identity metadata differs.
Контуры, интервалы, кернинг, лигатуры и ударения совпадают с выпуском 1.111.
Изменены только внутренние названия и идентификаторы, чтобы копия могла
устанавливаться рядом с основным семейством.

Source / Исходники: https://github.com/rahatulyerbolat05-dotcom/Very-Peri-serif
Licence / Лицензия: SIL Open Font License 1.1, see OFL.txt.
