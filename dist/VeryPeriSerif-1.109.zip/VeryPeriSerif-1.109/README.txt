Very Peri Serif 1.109
=====================

A Cyrillic extension of Instrument Serif: Russian and Kazakh in the Regular and the Italic.
Кириллическое расширение Instrument Serif: русский и казахский, начертания Regular и Italic.

Install / Установка
  Desktop (Windows, macOS, Linux, Figma, Adobe, Office): install both files from fonts/ttf
  (or fonts/otf; install one format, not both).
  Компьютер: установите оба файла из fonts/ttf (или fonts/otf; один формат, не оба).
  Web / сайт: fonts/webfonts, connect very-peri-serif.css.

Versions: Regular 1.109, Italic 1.109. Russian, Kazakh and inherited Latin; designed for display use.
Версии: Regular 1.109, Italic 1.109. Русский, казахский и исходная латиница; акцидентный шрифт.
Tabular figures: enable tnum. / Табличные цифры: включите tnum.
family.html is a live-font specimen. Family-Specimen.pdf contains outline examples of both styles and features.
family.html — образец с живым текстом; Family-Specimen.pdf — векторные образцы обоих начертаний и функций.

Licence / Лицензия
  SIL Open Font License 1.1 (OFL.txt). Free to use in any work, commercial included: print, logos, sites, apps.
  The font file itself may not be sold on its own; a modified version must stay under the OFL, and the names
  of the authors may not be used to promote it without their permission. The exact conditions are in OFL.txt.
  Можно использовать в любых работах, в том числе коммерческих. Нельзя продавать сам файл шрифта отдельно;
  изменённая версия остаётся под OFL, имена авторов нельзя использовать для её рекламы без их согласия.
  Точные условия в OFL.txt.

AI / ИИ
  The Cyrillic outlines were made with AI assistance (Anthropic Claude, OpenAI Codex) under the direction of the
  author; the Latin is Instrument Serif, unchanged. ai-disclosure.json, FONTLOG.txt.
  Кириллица сделана с помощью ИИ под руководством автора; латиница Instrument Serif не изменена.

Authors / Авторы: AUTHORS.txt, CONTRIBUTORS.txt. Source / Исходники: https://github.com/rahatulyerbolat05-dotcom/Very-Peri-serif
